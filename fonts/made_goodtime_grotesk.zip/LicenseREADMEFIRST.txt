
MadeType
behance.com/madetype

https://www.fontspring.com/fonts/madetype
https://creativemarket.com/MadeType
https://thehungryjpeg.com/madetype

END USER LICENSE AGREEMENT

- FOR PERSONAL USE. 

- Contact me at Madetypeinfo@gmail.com before commercial using it.

- MadeType is not liable for any damage resulting from the use ot this typeface.

- All rights are retained by MadeType.


THANK YOU!
